# Qibla Directory Importer

A plugin to import the Qibla Directory demo content.

## Requirements
* **Php** >= 5.3.x
* **WordPress** >= 4.6
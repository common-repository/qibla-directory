<?php // silence is golden.
